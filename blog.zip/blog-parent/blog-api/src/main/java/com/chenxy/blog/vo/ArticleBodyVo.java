package com.chenxy.blog.vo;

import lombok.Data;

import java.util.List;

@Data
public class ArticleBodyVo {
    //内容
    private String content;

}
